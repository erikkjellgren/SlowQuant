from collections.abc import Sequence

import numpy as np

from slowquant.molecularintegrals.integralfunctions import (
     generalized_one_electron_transform,
)
from slowquant.qiskit_interface.linear_response.generalized_lr_baseclass import (
    get_num_CBS_elements,
    get_num_nonCBS,
    quantumLRBaseClass,
)

from slowquant.qiskit_interface.util import Clique
from slowquant.unitary_coupled_cluster.generalized_density_matrix import (
    get_orbital_gradient_response_real_imag,
    get_orbital_response_hessian_block,
    get_orbital_response_metric_sigma,
    get_orbital_response_property_gradient_annika,
)
from slowquant.unitary_coupled_cluster.fermionic_operator import FermionicOperator
from slowquant.unitary_coupled_cluster.operators import (
    commutator,
    double_commutator,)
from slowquant.unitary_coupled_cluster.generalized_operators import (
    generalized_hamiltonian_2i_2a,
    generalized_hamiltonian_full_space,
    generalized_one_elec_op_0i_0a,
)

from slowquant.unitary_coupled_cluster.generalized_operator_state_algebra import (generalized_expectation_value)

class quantumLR(quantumLRBaseClass):
    def run(
        self,
        do_rdm: bool = True,
        do_gradients: bool = True,
    ) -> None:
        """Run simulation of naive LR matrix elements.

        Args:
            do_rdm: Use RDMs for QQ part.
            do_gradients: Calculate gradients w.r.t. orbital rotations and active space excitations.
        """
        idx_shift = len(self.q_ops)
        # idx_shift = self.num_q
        print("Gs", self.num_G)
        print("qs", self.num_q)
 
        "Pernille Screening"
        # Screen for A_ii = 0 Pernille
        finite_excitations = []
        if len(self.q_ops) != 0:
            A_matrix = get_orbital_response_hessian_block(
                self.wf.h_mo,
                self.wf.g_mo,
                self.wf.kappa_no_activeactive_spin_idx_dagger,
                self.wf.kappa_no_activeactive_spin_idx,
                self.wf.num_inactive_spin_orbs,
                self.wf.num_active_spin_orbs,
                self.wf.rdm1,
                self.wf.rdm2,
            )
              
        # # Man behøver ikke regne hele A, men det er bare lige nemt at gøre for qq
        for i, q in enumerate(self.q_ops):
            if abs(A_matrix[i, i]) > 10**-6:  # whatever rimeligt threshold
                finite_excitations.append(True)
            else:
                finite_excitations.append(False)
        self.q_ops_finite = sum(bool(x) for x in finite_excitations)
        
        for i, G in enumerate(self.G_ops):
            # <0| Gd H G |0>
            A = self.wf.QI.quantum_expectation_value_complex(
                (G.dagger * self.H_1i_1a * G).get_folded_operator(*self.orbs)
            )
            if abs(A) > 10**-6:  # whatever rimeligt threshold 
                finite_excitations.append(True)
            else:
                finite_excitations.append(False)
        self.G_ops_finite = sum(bool(x) for x in finite_excitations[len(self.q_ops):])
        finite_excitations_idx = np.array(finite_excitations)
        self.finite_excitations_idx = finite_excitations_idx
        

        if self.num_q != 0:
            if do_rdm:
                self.wf.precalc_rdm_paulis(2)
                # RDMs
                if do_gradients:
                    # Check gradients
                    grad = get_orbital_gradient_response_real_imag(
                        self.wf.h_mo,
                        self.wf.g_mo,
                        self.wf.kappa_no_activeactive_spin_idx,
                        self.wf.num_inactive_spin_orbs,
                        self.wf.num_active_spin_orbs,
                        self.wf.rdm1,
                        self.wf.rdm2,
                    )
            elif do_gradients:
                grad = np.zeros(2 * self.num_q, dtype=complex)
                for i, op in enumerate(self.q_ops):
                    grad[i] = self.wf.QI.quantum_expectation_value_complex(
                        (self.H_1i_1a * op).get_folded_operator(*self.orbs)
                    )
                    grad[i + self.num_q] = self.wf.QI.quantum_expectation_value_complex(
                        (op.dagger * self.H_1i_1a).get_folded_operator(*self.orbs)
                    )
        if do_gradients:
            if self.num_q != 0:
                print("idx, max(abs(grad orb)):", np.argmax(np.abs(grad)), np.max(np.abs(grad)))
                if np.max(np.abs(grad)) > 10**-3:
                    print("WARNING: Large Gradient detected in q of ", np.max(np.abs(grad)))

            grad = np.zeros(2 * self.num_G, dtype=complex)
            for i, op in enumerate(self.G_ops):
                grad[i] = self.wf.QI.quantum_expectation_value_complex(
                    commutator(self.H_0i_0a, op).get_folded_operator(*self.orbs)
                )
                grad[i + self.num_G] = self.wf.QI.quantum_expectation_value_complex(
                    commutator(op.dagger, self.H_0i_0a).get_folded_operator(*self.orbs)
                )
            if len(grad) != 0:
                print("idx, max(abs(grad active)):", np.argmax(np.abs(grad)), np.max(np.abs(grad)))
                if np.max(np.abs(grad)) > 10**-3:
                    print("WARNING: Large Gradient detected in G of ", np.max(np.abs(grad)))


        # self.generalized_hamiltonian_full_space = generalized_hamiltonian_full_space(
        # self.wf.h_mo,
        # self.wf.g_mo,
        # self.wf.num_spin_orbs)


        # qq
        if self.num_q != 0:
            if do_rdm:
                self.A[: self.num_q, : self.num_q] = get_orbital_response_hessian_block(
                    self.wf.h_mo,
                    self.wf.g_mo,
                    self.wf.kappa_no_activeactive_spin_idx_dagger,
                    self.wf.kappa_no_activeactive_spin_idx,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                    self.wf.rdm2,
                )
                print(f"Hermiticity check of A: max|A - A†| efter qq= "
                f"{np.max(np.abs(self.A - self.A.conj().T)):.2e}")  


                self.B[: self.num_q, : self.num_q] = get_orbital_response_hessian_block(
                    self.wf.h_mo,
                    self.wf.g_mo,
                    self.wf.kappa_no_activeactive_spin_idx_dagger,
                    self.wf.kappa_no_activeactive_spin_idx_dagger,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                    self.wf.rdm2,
                )
                self.Sigma[: self.num_q, : self.num_q] = get_orbital_response_metric_sigma(
                    self.wf.kappa_no_activeactive_spin_idx,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                )
            else: 
                self.H_2i_2a = generalized_hamiltonian_2i_2a( #AE
                    self.wf.h_mo,
                    self.wf.g_mo,
                    self.wf.num_inactive_orbs,
                    self.wf.num_active_orbs,
                    self.wf.num_virtual_orbs,
                )
                # self.generalized_hamiltonian_full_space = generalized_hamiltonian_full_space(
                #     self.wf.h_mo,
                #     self.wf.g_mo,
                #     self.wf.num_spin_orbs)
                
                for j, qJ in enumerate(self.q_ops):
                    for i, qI in enumerate(self.q_ops[j:], j):
                        # Make A
                        val = self.wf.QI.quantum_expectation_value_complex(
                            (qI.dagger * self.H_2i_2a * qJ).get_folded_operator(*self.orbs)
                        ) - self.wf.QI.quantum_expectation_value_complex(
                            (qI.dagger * qJ * self.H_2i_2a).get_folded_operator(*self.orbs)
                        )
                        self.A[i, j] = val

                        self.A[j, i] = val.conj()

                        # Make B
                        self.B[i, j] = self.B[j, i] = -(
                            self.wf.QI.quantum_expectation_value_complex(
                                (qI.dagger * qJ.dagger *self.H_2i_2a).get_folded_operator(*self.orbs)
                            )
                        )
                        # Make Sigma
                        val = self.wf.QI.quantum_expectation_value_complex(
                            (qI.dagger * qJ).get_folded_operator(*self.orbs)
                        )
                        self.Sigma[i, j] = val

                        self.Sigma[j, i] = val.conj()

            # Gq
            for j, qJ in enumerate(self.q_ops):
                for i, GI in enumerate(self.G_ops):
                    # Make A
                    val = (
                        self.wf.QI.quantum_expectation_value_complex( #AE complex ALLE STEDER!??
                            (GI.dagger * self.H_1i_1a * qJ).get_folded_operator(*self.orbs)
                        )
                        - 1
                        / 2
                        * self.wf.QI.quantum_expectation_value_complex(
                            (self.H_1i_1a * qJ * GI.dagger).get_folded_operator(*self.orbs)
                        )
                        - 1
                        / 2
                        * self.wf.QI.quantum_expectation_value_complex(
                            (self.H_1i_1a * GI.dagger * qJ).get_folded_operator(*self.orbs)
                        )
                    )
                    self.A[i + idx_shift, j] = val
                    self.A[j, i + idx_shift] = val.conj()
                    
                    # Make B
                    val = (
                        self.wf.QI.quantum_expectation_value_complex(
                            (qJ.dagger * self.H_1i_1a * GI.dagger).get_folded_operator(*self.orbs)
                        )
                        - 1
                        / 2
                        * self.wf.QI.quantum_expectation_value_complex(
                            (GI.dagger * qJ.dagger * self.H_1i_1a).get_folded_operator(*self.orbs)
                        )
                        - 1
                        / 2
                        * self.wf.QI.quantum_expectation_value_complex(
                            (qJ.dagger * GI.dagger * self.H_1i_1a).get_folded_operator(*self.orbs)
                        )
                    )
                    self.B[i + idx_shift, j] = self.B[j, i + idx_shift] = val

       # GG
        for j, GJ in enumerate(self.G_ops):
            for i, GI in enumerate(self.G_ops[j:], j):
                # Make A

                val = self.wf.QI.quantum_expectation_value_complex(double_commutator(GI.dagger, self.H_0i_0a, GJ, do_symmetrized=True).get_folded_operator(*self.orbs))
                self.A[i + idx_shift, j + idx_shift] = val
                self.A[j + idx_shift, i + idx_shift] = val.conj()

                #AE
                # self.A[i + idx_shift, j + idx_shift] =  (
                #     self.wf.QI.quantum_expectation_value_complex(
                #         double_commutator(
                #             GI.dagger,self.H_0i_0a, GJ, do_symmetrized=True
                #         ).get_folded_operator(*self.orbs)
                #     )
                # )

                # self.A[j + idx_shift, i + idx_shift] = (
                #     self.wf.QI.quantum_expectation_value_complex(
                #         double_commutator(
                #             GI.dagger, self.H_0i_0a, GJ, do_symmetrized=True
                #         ).get_folded_operator(*self.orbs)
                #     )
                # ).conj()

                # Make B
                self.B[i + idx_shift, j + idx_shift]  = self.B[j + idx_shift, i + idx_shift] = (
                    self.wf.QI.quantum_expectation_value_complex(
                        double_commutator(GI.dagger, self.H_0i_0a, GJ.dagger).get_folded_operator(*self.orbs)
                    )
                )
                # Make Sigma
                val=(
                    self.wf.QI.quantum_expectation_value_complex(
                        commutator(GI.dagger, GJ).get_folded_operator(*self.orbs)
                    )
                )
                self.Sigma[i + idx_shift, j + idx_shift] = val  
                self.Sigma[j + idx_shift, i + idx_shift] = val.conj()

        # Check hermiticity of the Hessian:
        size = len(self.A)
        E2 = np.zeros((size * 2, size * 2), dtype=complex) #AE complex
        E2[:size, :size] = self.A
        E2[:size, size:] = self.B
        E2[size:, :size] = self.B.conjugate() #AE added conjugtate 
        E2[size:, size:] = self.A.conjugate() #AE added conjugtate 

        #test anna
        # self.A = 1/2*(self.A+self.A.conj().T)
        # self.Sigma = 1/2*(self.Sigma+self.Sigma.conj().T)


        
        # print('Circuit', self.A)

        # print(f"Hermiticity check of the Hessian: max|E2 - E2†| = "
        #     f"{np.max(np.abs(E2 - E2.conj().T)):.2e}")  

        print(f"Hermiticity check of A: max|A - A†| = "
            f"{np.max(np.abs(self.A - self.A.conj().T)):.2e}")  


        print(f"Symmetry check of B: max|B - B.T| = "
            f"{np.max(np.abs(self.B - self.B.T)):.2e}")  
        
        print(f"Hermiticity check of A: max|Sigma - Sigma†| = "
            f"{np.max(np.abs(self.Sigma - self.Sigma.conj().T)):.2e}")  

        
        print("Hessian is real?", np.allclose(E2.imag, 0))
        print("Largest imaginary value in Hessian",np.max(np.imag(E2)))
                        
        # print("H shape:", E2.shape)
        # print("sigma shape:", self.Sigma.shape)
        # print("H diagonal:", np.diag(E2).real)
        # print("sigma diagonal:", np.diag(self.Sigma).real)
        



        "Screening af A - Pernille"
        self.A = self.A[np.outer(finite_excitations_idx, finite_excitations_idx)].reshape(
                    (np.sum(finite_excitations_idx), np.sum(finite_excitations_idx))
                )
        self.B = self.B[np.outer(finite_excitations_idx, finite_excitations_idx)].reshape(
                    (np.sum(finite_excitations_idx), np.sum(finite_excitations_idx))
                )
        self.Sigma = self.Sigma[np.outer(finite_excitations_idx, finite_excitations_idx)].reshape(
                    (np.sum(finite_excitations_idx), np.sum(finite_excitations_idx))
                )
        self.Delta = np.zeros((len(self.Sigma), len(self.Sigma))
        )  # Delta er defineret her fordi den ellers har forkert dimension i unrestricted_lr_baseclass.py



    def _get_qbitmap(
        self,
        cliques: bool = False,
        do_rdm: bool = False,
    ) -> tuple[list[list[str]], list[list[str]], list[list[str]]]:
        """Get qubit map of operators.

        Args:
            cliques: If using cliques.
            do_rdm: Use RDMs for QQ part.

        Returns:
            Qubit map of operators.
        """

        print('Renato is spiderman')
        idx_shift = self.num_q
        print("Gs", self.num_G)
        print("qs", self.num_q)

        A = [[""] * self.num_params for _ in range(self.num_params)]
        B = [[""] * self.num_params for _ in range(self.num_params)]
        Sigma = [[""] * self.num_params for _ in range(self.num_params)]

        if not do_rdm:
            # self.H_2i_2a = hamiltonian_2i_2a(
            #     self.wf.h_mo,
            #     self.wf.g_mo,
            #     self.wf.num_inactive_orbs,
            #     self.wf.num_active_orbs,
            #     self.wf.num_virtual_orbs,
            # )
            self.generalized_hamiltonian_full_space = generalized_hamiltonian_full_space(
                    self.wf.h_mo,
                    self.wf.g_mo,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.num_virtual_spin_orbs)
            
            for j, qJ in enumerate(self.q_ops):
                for i, qI in enumerate(self.q_ops[j:], j):
                    # Make A
                    A[i][j] = A[j][i] = (
                        self.wf.QI.op_to_qbit(
                            (qI.dagger * self.generalized_hamiltonian_full_space * qJ).get_folded_operator(*self.orbs)
                        ).paulis.to_labels()
                        + self.wf.QI.op_to_qbit(
                            (qI.dagger * qJ * self.generalized_hamiltonian_full_space).get_folded_operator(*self.orbs)
                        ).paulis.to_labels()
                    )
                    # Make B
                    B[i][j] = B[j][i] = self.wf.QI.op_to_qbit(
                        (qI.dagger * qJ.dagger * self.generalized_hamiltonian_full_space).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                    # Make Sigma
                    Sigma[i][j] = Sigma[j][i] = self.wf.QI.op_to_qbit(
                        (qI.dagger * qJ).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()

        # Gq
        for j, qJ in enumerate(self.q_ops):
            for i, GI in enumerate(self.G_ops):
                # Make A
                val = (
                    self.wf.QI.op_to_qbit(
                        (GI.dagger * self.H_1i_1a * qJ).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                    + self.wf.QI.op_to_qbit(
                        (self.H_1i_1a * qJ * GI.dagger).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                    + self.wf.QI.op_to_qbit(
                        (self.H_1i_1a * GI.dagger * qJ).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                )
                A[i + idx_shift][j] = A[j][i + idx_shift] = val
                # Make B
                val = (
                    self.wf.QI.op_to_qbit(
                        (qJ.dagger * self.H_1i_1a * GI.dagger).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                    + self.wf.QI.op_to_qbit(
                        (GI.dagger * qJ.dagger * self.H_1i_1a).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                    + self.wf.QI.op_to_qbit(
                        (qJ.dagger * GI.dagger * self.H_1i_1a).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                )
                B[i + idx_shift][j] = B[j][i + idx_shift] = val

        # GG
        for j, GJ in enumerate(self.G_ops):
            for i, GI in enumerate(self.G_ops[j:], j):
                # Make A
                A[i + idx_shift][j + idx_shift] =  self.wf.QI.op_to_qbit(
                    double_commutator(GI.dagger, self.H_1i_1a, GJ, do_symmetrized=True).get_folded_operator(
                        *self.orbs
                    )
                ).paulis.to_labels()

                A[j + idx_shift][i + idx_shift] = self.wf.QI.op_to_qbit(
                    double_commutator(GI.dagger, self.H_1i_1a, GJ, do_symmetrized=True).get_folded_operator(
                        *self.orbs
                    ).conj()
                ).paulis.to_labels()

                # Make B
                B[i + idx_shift][j + idx_shift] = B[j + idx_shift][i + idx_shift] = self.wf.QI.op_to_qbit(
                    double_commutator(GI.dagger, self.H_1i_1a, GJ.dagger).get_folded_operator(*self.orbs)
                ).paulis.to_labels()
                
                # Make Sigma
                Sigma[i + idx_shift][j + idx_shift] = (
                    self.wf.QI.op_to_qbit(
                        commutator(GI.dagger, GJ).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                )
                Sigma[j + idx_shift][i + idx_shift] = (
                    self.wf.QI.op_to_qbit(
                        commutator(GI.dagger, GJ).get_folded_operator(*self.orbs)
                    ).paulis.to_labels()
                ).conj()

        if cliques:
            for i in range(self.num_params):
                for j in range(self.num_params):
                    if not A[i][j] == "":
                        clique = Clique()
                        clique.add_paulis([str(x) for x in A[i][j]])
                        A[i][j] = [x.head for x in clique.cliques]  # type: ignore [call-overload]
                    if not B[i][j] == "":
                        clique = Clique()
                        clique.add_paulis([str(x) for x in B[i][j]])
                        B[i][j] = [x.head for x in clique.cliques]  # type: ignore [call-overload]
                    if not Sigma[i][j] == "":
                        clique = Clique()
                        clique.add_paulis([str(x) for x in Sigma[i][j]])
                        Sigma[i][j] = [x.head for x in clique.cliques]  # type: ignore [call-overload]

        print("Number of non-CBS Pauli strings in A: ", get_num_nonCBS(A))
        print("Number of non-CBS Pauli strings in B: ", get_num_nonCBS(B))
        print("Number of non-CBS Pauli strings in Sigma: ", get_num_nonCBS(Sigma))

        CBS, nonCBS = get_num_CBS_elements(A)
        print("In A    , number of: CBS elements: ", CBS, ", non-CBS elements ", nonCBS)
        CBS, nonCBS = get_num_CBS_elements(B)
        print("In B    , number of: CBS elements: ", CBS, ", non-CBS elements ", nonCBS)
        CBS, nonCBS = get_num_CBS_elements(Sigma)
        print("In Sigma, number of: CBS elements: ", CBS, ", non-CBS elements ", nonCBS)

        return A, B, Sigma

    def run_std(
        self,
        no_coeffs: bool = False,
        verbose: bool = True,
        cv: bool = True,
        save: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Get standard deviation in matrix elements of LR equation.

        Args:
            no_coeffs:  Boolean to no include coefficients
            verbose:    Boolean to print more info
            cv:         Boolean to calculate coefficient of variance
            save:       Boolean to save operator-specific standard deviations

        Returns:
            Array of standard deviations for A, B and Sigma
        """

        print('Renarto is batman')
        idx_shift = self.num_q
        print("Gs", self.num_G)
        print("qs", self.num_q)

        # self.H_2i_2a = hamiltonian_2i_2a(
        #     self.wf.h_mo,
        #     self.wf.g_mo,
        #     self.wf.num_inactive_orbs,
        #     self.wf.num_active_orbs,
        #     self.wf.num_virtual_orbs,
        # )

        self.generalized_hamiltonian_full_space = generalized_hamiltonian_full_space(
                    self.wf.h_mo,
                    self.wf.g_mo,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.num_virtual_spin_orbs,)

        A = np.zeros((self.num_params, self.num_params))
        B = np.zeros((self.num_params, self.num_params))
        Sigma = np.zeros((self.num_params, self.num_params))

        for j, qJ in enumerate(self.q_ops):
            for i, qI in enumerate(self.q_ops[j:], j):
                # Make A
                A[i, j] = A[j, i] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        (qI.dagger * self.generalized_hamiltonian_full_space * qJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                    + self.wf.QI.quantum_variance(
                        (qI.dagger * qJ * self.generalized_hamiltonian_full_space).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                )
                # Make B
                B[i, j] = B[j, i] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        (qI.dagger * qJ.dagger * self.generalized_hamiltonian_full_space).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                )
                # Make Sigma
                Sigma[i, j] = Sigma[j, i] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        (qI.dagger * qJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                )

        # Gq
        for j, qJ in enumerate(self.q_ops):
            for i, GI in enumerate(self.G_ops):
                # Make A
                val = np.sqrt(
                    self.wf.QI.quantum_variance(
                        (GI.dagger * self.H_1i_1a * qJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                    + 1
                    / 2
                    * self.wf.QI.quantum_variance(
                        (self.H_1i_1a * qJ * GI.dagger).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                    + 1
                    / 2
                    * self.wf.QI.quantum_variance(
                        (self.H_1i_1a * GI.dagger * qJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                )
                A[i + idx_shift, j] = A[j, i + idx_shift] = val
                # Make B
                val = np.sqrt(
                    self.wf.QI.quantum_variance(
                        (qJ.dagger * self.H_1i_1a * GI.dagger).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                    + 1
                    / 2
                    * self.wf.QI.quantum_variance(
                        (GI.dagger * qJ.dagger * self.H_1i_1a).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                    + 1
                    / 2
                    * self.wf.QI.quantum_variance(
                        (qJ.dagger * GI.dagger * self.H_1i_1a).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                )
                B[i + idx_shift, j] = B[j, i + idx_shift] = val

        # GG
        for j, GJ in enumerate(self.G_ops):
            for i, GI in enumerate(self.G_ops[j:], j):
                # Make A
                A[i + idx_shift, j + idx_shift] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        double_commutator(
                            GI.dagger, self.H_0i_0a, GJ, do_symmetrized=True
                        ).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                )

                A[j + idx_shift, i + idx_shift] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        double_commutator(
                            GI.dagger, self.H_0i_0a, GJ, do_symmetrized=True
                        ).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                ).conj()
                # Make B
                B[i + idx_shift, j + idx_shift] = B[j + idx_shift, i + idx_shift] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        double_commutator(GI.dagger, self.H_0i_0a, GJ.dagger).get_folded_operator(*self.orbs),
                        no_coeffs=no_coeffs,
                    )
                )
                # Make Sigma
                Sigma[i + idx_shift, j + idx_shift] = Sigma[j + idx_shift, i + idx_shift] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        commutator(GI.dagger, GJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )
                )
                Sigma[j + idx_shift, i + idx_shift] = np.sqrt(
                    self.wf.QI.quantum_variance(
                        commutator(GI.dagger, GJ).get_folded_operator(*self.orbs), no_coeffs=no_coeffs
                    )).conj()
                

        if no_coeffs:
            cv = False
        self._analyze_std(A, B, Sigma, verbose=verbose, cv=cv, save=save)
        return A, B, Sigma

    def get_transition_dipole(self, dipole_integrals: Sequence[np.ndarray]) -> np.ndarray:
        """Calculate transition dipole moment.

        Args:
            dipole_integrals: Dipole integrals ordered as (x,y,z).

        Returns:
            Transition dipole moment.
        """
        if len(dipole_integrals) != 3:
            raise ValueError(f"Expected 3 dipole integrals got {len(dipole_integrals)}")
        number_excitations = len(self.excitation_energies)

        mux =  generalized_one_electron_transform(self.wf.c_mo, dipole_integrals[0])
        muy =  generalized_one_electron_transform(self.wf.c_mo, dipole_integrals[1])
        muz =  generalized_one_electron_transform(self.wf.c_mo, dipole_integrals[2])
        mux_op = generalized_one_elec_op_0i_0a(mux, self.wf.num_inactive_spin_orbs, self.wf.num_active_spin_orbs)
        muy_op = generalized_one_elec_op_0i_0a(muy, self.wf.num_inactive_spin_orbs, self.wf.num_active_spin_orbs)
        muz_op = generalized_one_elec_op_0i_0a(muz, self.wf.num_inactive_spin_orbs, self.wf.num_active_spin_orbs)
        transition_dipole_x = 0.0 + 0.0j
        transition_dipole_y = 0.0 + 0.0j
        transition_dipole_z = 0.0 + 0.0j
        transition_dipoles = np.zeros((number_excitations, 3), dtype=np.complex128)
        shift = self.q_ops_finite #AE
        
        nq = len(self.q_ops)
        q_mask = self.finite_excitations_idx[:nq]

        kappa_fin = [kappa for kappa, keep in zip(self.wf.kappa_no_activeactive_spin_idx, q_mask) if keep]
        assert len(kappa_fin) == shift

        for state_number in range(number_excitations):
            transfer_op = FermionicOperator({})
            # for i, G in enumerate(self.G_ops):
            #     transfer_op += (
            #         # self._Z_G_normed[i, state_number] * G.dagger + self._Y_G_normed[i, state_number] * G #Pernille
            #         # self._Z_qG_normed[i, state_number] * G.dagger + self._Y_qG_normed[i, state_number] * G



            #         # self._Z_qG_normed[i+shift, state_number] * G.dagger + self._Y_qG_normed[i+shift, state_number] * G #AE SHIFT MANGLER
            #         self._Z_qG_normed[i+shift, state_number] * G + self._Y_qG_normed[i+shift, state_number] * G.dagger #AE SHIFT MANGLER



            #     )
            G_kept = [G for G, keep in zip(self.G_ops, self.finite_excitations_idx[nq:]) if keep] 
            for i, G in enumerate(G_kept):
                transfer_op += self._Z_qG_normed[i+shift, state_number] * G + self._Y_qG_normed[i+shift, state_number] * G.dagger
            q_part_x = 0.0
            q_part_y = 0.0
            q_part_z = 0.0
            if self.num_q != 0:
                q_part_x = get_orbital_response_property_gradient_annika(
                    mux,
                    kappa_fin,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                    self.normed_excitation_vectors,
                    state_number,
                    number_excitations,
                )
                q_part_y = get_orbital_response_property_gradient_annika(
                    muy,
                    kappa_fin,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                    self.normed_excitation_vectors,
                    state_number,
                    number_excitations,
                )
                q_part_z = get_orbital_response_property_gradient_annika(
                    muz,
                    kappa_fin,
                    self.wf.num_inactive_spin_orbs,
                    self.wf.num_active_spin_orbs,
                    self.wf.rdm1,
                    self.normed_excitation_vectors,
                    state_number,
                    number_excitations,
                )
            if self.num_G != 0:
                transition_dipole_x = self.wf.QI.quantum_expectation_value_complex(
                    commutator(mux_op, transfer_op).get_folded_operator(*self.orbs)
                )
                transition_dipole_y = self.wf.QI.quantum_expectation_value_complex(
                    commutator(muy_op, transfer_op).get_folded_operator(*self.orbs)
                )
                transition_dipole_z = self.wf.QI.quantum_expectation_value_complex(
                    commutator(muz_op, transfer_op).get_folded_operator(*self.orbs)
                )
            transition_dipoles[state_number, 0] = - q_part_x + transition_dipole_x
            transition_dipoles[state_number, 1] = - q_part_y + transition_dipole_y
            transition_dipoles[state_number, 2] = - q_part_z + transition_dipole_z

        return transition_dipoles
