import time

import numpy as np
import scipy

from slowquant.qiskit_interface.fast_pauli import FermionPauliMap, PauliEstimator
from slowquant.unitary_coupled_cluster.DHF_integral_direct import DirectState, orbital_gradient
from slowquant.unitary_coupled_cluster.generalized_ups_wavefunction_DHF import GeneralizedWaveFunctionUPS
from slowquant.unitary_coupled_cluster.printing import IterationTable


def shift_rule(R: int, order: int) -> tuple[np.ndarray, np.ndarray]:
    """Shifts and weights of the general parameter-shift rule for E(x) with frequencies 1..R (Wierichs et al., Quantum 6, 677 (2022)).

    order 1: E'(0) = sum_mu w_mu E(x_mu), x_mu = (2mu-1)pi/(2R), mu = 1..2R.
    order 2: E''(0) = sum_mu w_mu E(x_mu), x_0 = 0, x_mu = mu pi/R, mu = 1..2R-1.
    """
    if order == 1:
        mu = np.arange(1, 2 * R + 1)
        x = (2 * mu - 1) * np.pi / (2 * R)
        return x, (-1.0) ** (mu - 1) / (4 * R * np.sin(x / 2) ** 2)
    mu = np.arange(1, 2 * R)
    x = mu * np.pi / R
    return np.concatenate(([0.0], x)), np.concatenate(
        ([-(2 * R**2 + 1) / 6], (-1.0) ** (mu - 1) / (2 * np.sin(x / 2) ** 2))
    )


class GeneralizedWaveFunctionCircuitDHF(GeneralizedWaveFunctionUPS):
    """4c (DHF-based) orbital-optimized circuit wave function, quantum-hardware compatible.

    The device only delivers Pauli expectation values of the ansatz circuit. RDMs, energies and orbital
    gradients are classical contractions (integral-direct Fock matrices, no MO integrals beyond (N a|a a)).
    Theta parameters are the QI circuit parameters (norm r and phase phi per excitation).
    """

    def __init__(
        self,
        cas: tuple[tuple[int, int], int],
        mo_coeffs: np.ndarray,
        mol,
        quantum_interface,
        include_active_kappa: bool = False,
        direct=None,
        exact: bool | None = None,
    ) -> None:
        super().__init__(
            cas, np.asarray(mo_coeffs, dtype=complex), mol, [], False, "adapt", {}, include_active_kappa
        )
        if direct is not None:
            self._direct = direct
        self.QI = quantum_interface
        self.QI.construct_circuit(
            self.active_occ_spin_idx_shifted,
            self.active_unocc_spin_idx_shifted,
            self.num_active_spin_orbs,
            (self.num_active_elec_alpha, self.num_active_elec_beta),
        )
        Rr, Rp = self.QI.grad_param_R_r, self.QI.grad_param_R_phi
        self.R = np.array([Rr[n] if n in Rr else Rp[n] for n in self.QI.param_names], dtype=int)
        self.pmap = FermionPauliMap(self.QI, self.num_active_spin_orbs)
        self.estimator = PauliEstimator(self.QI, exact)
        n = self.QI.circuit.num_parameters // 2
        self._thetas_real = [0.0] * n
        self._thetas_imag = [0.0] * n
        self.QI.parameters = [0.0] * (2 * n)
        self._hk = None
        self._fixed_rdms = False
        self.num_energy_evals = 0
        self.parameter_shift = False

    @property
    def thetas(self) -> list[float]:
        return list(self.QI.parameters)

    def set_thetas(self, theta_r: list[float], theta_phi: list[float]) -> None:
        """Set circuit parameters (norms r and phases phi)."""
        self._thetas_real = [float(x) for x in theta_r]
        self._thetas_imag = [float(x) for x in theta_phi]
        self.QI.parameters = self._thetas_real + self._thetas_imag
        self._rdm1 = None
        self._rdm2 = None
        self._energy_elec = None

    def set_thetas_initial(self, theta_real: list[float], theta_imag: list[float]) -> None:
        """Set parameters from Cartesian theta = theta_real + i theta_imag."""
        self.set_thetas(np.hypot(theta_real, theta_imag), np.arctan2(theta_imag, theta_real))

    def set_integral_backend(self, direct) -> None:
        super().set_integral_backend(direct)
        self._hk = None

    def _set_orbitals(self, C: np.ndarray) -> None:
        super()._set_orbitals(C)
        self._hk = None

    def _make_rdms(self) -> None:
        self._rdm1, self._rdm2 = self.pmap.rdms(self.estimator(self.pmap.keys))

    def _get_direct_state(self, C: np.ndarray, attr: str) -> DirectState:
        for ds in (self._ds, self._ds_ep):
            if ds is not None and np.array_equal(ds.C, C):
                setattr(self, attr, ds)
                return ds
        ds = DirectState(self._direct, C, self.inactive_spin_idx, self.active_spin_idx, self._rdm1)
        setattr(self, attr, ds)
        return ds

    @property
    def energy_elec(self) -> float:
        if self._energy_elec is None:
            self._energy_elec = self.ds.energy(self.rdm1, self.rdm2)
        return self._energy_elec

    def _hamiltonian_paulis(self) -> tuple[np.ndarray, np.ndarray]:
        if self._hk is None:
            c = self.pmap.hamiltonian_coefficients(*self.ds.active_integrals())
            nz = np.abs(c) > 1e-12
            self._hk = (self.pmap.keys[nz], c[nz])
        return self._hk

    def theta_energy(self, p) -> float:
        """<H> at circuit parameters p for the current orbitals."""
        keys, c = self._hamiltonian_paulis()
        self.num_energy_evals += 1
        return float((self.estimator(keys, p) @ c).real)

    def _energies(self, points) -> np.ndarray:
        keys, c = self._hamiltonian_paulis()
        self.num_energy_evals += len(points)
        return self.estimator.expectation_multi(keys, c, points).real

    def theta_gradient(self, p=None) -> np.ndarray:
        """Parameter-shift gradient (all shifted circuits in one batch). On the exact (statevector) path the same
        gradient is obtained by adjoint differentiation (two sweeps) unless self.parameter_shift is True."""
        p = np.array(self.thetas if p is None else p, dtype=float)
        if self.estimator.exact and not self.parameter_shift:
            res = self.estimator.energy_gradient(*self._hamiltonian_paulis(), p)
            if res is not None:
                self.num_energy_evals += 2
                return res[1]
        pts, w, idx = [], [], []
        for i, R in enumerate(self.R):
            for x, wt in zip(*shift_rule(R, 1)):
                q = p.copy()
                q[i] += x
                pts.append(q)
                w.append(wt)
                idx.append(i)
        g = np.zeros(len(p))
        np.add.at(g, idx, np.array(w) * self._energies(pts))
        return g

    def theta_hessian(self, p=None) -> np.ndarray:
        """Parameter-shift Hessian: second-derivative rule on the diagonal, product of first-derivative rules off it.
        Exact path (unless self.parameter_shift): first-derivative shift rule applied to adjoint gradients (exact)."""
        p = np.array(self.thetas if p is None else p, dtype=float)
        n = len(p)
        if self.estimator.exact and not self.parameter_shift and self.estimator._simulator() is not None:
            H = np.zeros((n, n))
            for i in range(n):
                for x, wt in zip(*shift_rule(self.R[i], 1)):
                    q = p.copy()
                    q[i] += x
                    H[i] += wt * self.theta_gradient(q)
            return 0.5 * (H + H.T)
        pts, w, ij = [], [], []
        for i in range(n):
            for x, wt in zip(*shift_rule(self.R[i], 2)):
                q = p.copy()
                q[i] += x
                pts.append(q)
                w.append(wt)
                ij.append((i, i))
            xi, wi = shift_rule(self.R[i], 1)
            for j in range(i + 1, n):
                xj, wj = shift_rule(self.R[j], 1)
                for a, wa in zip(xi, wi):
                    for b, wb in zip(xj, wj):
                        q = p.copy()
                        q[i] += a
                        q[j] += b
                        pts.append(q)
                        w.append(wa * wb)
                        ij.append((i, j))
        H = np.zeros((n, n))
        ij = np.array(ij)
        np.add.at(H, (ij[:, 0], ij[:, 1]), np.array(w) * self._energies(pts))
        return H + np.triu(H, 1).T

    def _optimize_thetas(self, gtol: float, maxiter: int, method: str = "l-bfgs-b") -> float:
        """Theta optimization at fixed orbitals. method: any scipy.optimize.minimize method; Newton-type methods
        ('trust-exact', 'trust-krylov', 'newton-cg') use the parameter-shift Hessian."""
        if self._fixed_rdms:
            return self.energy_elec
        p0 = np.array(self.thetas, dtype=float)
        opts = {"maxiter": maxiter}
        kw = {}
        m = method.lower()
        if m in (
            "l-bfgs-b",
            "bfgs",
            "cg",
            "slsqp",
            "tnc",
            "trust-exact",
            "trust-krylov",
            "trust-ncg",
            "newton-cg",
        ):
            kw["jac"] = self.theta_gradient
            opts["gtol"] = gtol
        if m == "l-bfgs-b":
            opts.update({"ftol": 1e-16, "maxcor": 30})
        if m in ("trust-exact", "trust-krylov", "trust-ncg", "newton-cg"):
            kw["hess"] = self.theta_hessian
            if m == "newton-cg":
                opts.pop("gtol")
        res = scipy.optimize.minimize(self.theta_energy, p0, method=method, options=opts, **kw)
        n = len(p0) // 2
        self.set_thetas(res.x[:n], res.x[n:])
        return float(res.fun)

    def orbital_gradient_max(self) -> float:
        ds = self.ds
        ds.set_rdms(self.rdm1, self.rdm2)
        idx = [tuple(i) for i in self.kappa_spin_idx] + [tuple(i) for i in self.kappa_spin_idx_ep]
        g = orbital_gradient(ds.gen_fock(), idx)
        return float(np.abs(g).max()) if len(g) else 0.0

    def run_wf_optimization_2step_DHF(
        self,
        tol: float = 1e-5,
        maxiter: int = 50,
        theta_method: str = "l-bfgs-b",
        theta_gtol: float = 1e-8,
        theta_maxiter: int = 500,
        orbital_maxiter: int = 50,
        **orbital_options,
    ) -> None:
        """Hardware-friendly two-step OO: theta optimization (quantum) then orbital optimization at fixed measured
        RDMs (classical, integral-direct; L-BFGS e-e minimized, diagonal Newton e-p maximized).
        Quantum cost per macro iteration: theta optimization + one RDM measurement."""
        t_start = time.time()
        timing = {"theta optimization + RDMs": 0.0, "orbital optimization": 0.0}
        evals0 = self.num_energy_evals
        tab = IterationTable(
            "Circuit two-step orbital optimization, 4c (theta on device, orbitals classical)",
            [("Macro", 5, "d"), ("Time [s]", 9, ".2f"), ("E after theta [Eh]", 20, ".12f"), ("max|g_orb|", 10, ".2e"),
             ("E after orbitals [Eh]", 21, ".12f"), ("Orb.it", 6, "d"), ("Circuits", 9, "d")],
            [("Orbital rotations (complex)", f"{len(self.kappa_spin_idx) + len(self.kappa_spin_idx_ep)} ({len(self.kappa_spin_idx_ep)} e-p)"),
             ("Circuit parameters", len(self.thetas)), ("Theta optimizer", theta_method), ("Convergence", f"max|g_orb| < {tol:.1e}")],
        )
        conv = False
        for it in range(maxiter):
            t0 = time.time()
            e_theta = self._optimize_thetas(theta_gtol, theta_maxiter, theta_method)
            gmax = self.orbital_gradient_max()
            timing["theta optimization + RDMs"] += time.time() - t0
            if gmax < tol:
                tab.row(it + 1, tab.lap(), e_theta, gmax, None, None, self.num_energy_evals - evals0)
                conv = True
                break
            t1 = time.time()
            self._fixed_rdms = True
            try:
                n_orb = self.run_wf_optimization_direct_DHF(
                    tol=tol, maxiter=orbital_maxiter, print_iterations=False, **orbital_options
                )
            finally:
                self._fixed_rdms = False
            timing["orbital optimization"] += time.time() - t1
            self._energy_elec = None
            e_orb = self.ds.energy(self.rdm1, self.rdm2)
            tab.row(it + 1, tab.lap(), e_theta, gmax, e_orb, n_orb, self.num_energy_evals - evals0)
        self._energy_elec = None
        info = self._oo_summary(t_start, self.energy_elec, timing)
        info.insert(len(timing) + 1, ("Circuits evaluated", f"{self.num_energy_evals - evals0:20d}"))
        tab.close(
            f"Converged in {it + 1} macro iterations" if conv else f"WARNING: not converged in {maxiter} macro iterations", info
        )
        self._energy_elec = None
